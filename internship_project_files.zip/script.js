const internships = [
    { id: 1, title: "Frontend Developer", company: "Tech Solutions", domain: "development", tags: ["HTML", "CSS", "JS"] },
    { id: 2, title: "UI/UX Designer", company: "Creative Studio", domain: "design", tags: ["Figma", "UI", "UX"] },
    { id: 3, title: "Digital Marketing Intern", company: "Growth Media", domain: "marketing", tags: ["SEO", "SMM"] },
    { id: 4, title: "Backend Web Developer", company: "Data Systems", domain: "development", tags: ["Node.js", "SQL"] },
    { id: 5, title: "Graphic Designer", company: "Art Hub", domain: "design", tags: ["Photoshop", "Vector"] }
];
const container = document.getElementById("internships-container");
const searchInput = document.getElementById("search-input");
const domainSelect = document.getElementById("domain-select");
function displayInternships(list) {
    container.innerHTML = "";
    if (list.length === 0) {
        container.innerHTML = `<div class="empty-state">कोई इंटर्नशिप नहीं मिली। कृपया कुछ और सर्च करें।</div>`;
        return;
    }
    list.forEach(item => {
        const card = document.createElement("article");
        card.classList.add("card");
        const tagsHTML = item.tags.map(tag => `<span class="tag">${tag}</span>`).join("");
        card.innerHTML = `<h3>${item.title}</h3><p class="company">${item.company}</p><div class="tags">${tagsHTML}</div>`;
        container.appendChild(card);
    });
}
function filterData() {
    const searchText = searchInput.value.toLowerCase();
    const selectedDomain = domainSelect.value;
    const filtered = internships.filter(item => {
        const matchesSearch = item.title.toLowerCase().includes(searchText) || item.tags.some(t => t.toLowerCase().includes(searchText));
        const matchesDomain = selectedDomain === "all" || item.domain === selectedDomain;
        return matchesSearch && matchesDomain;
    });
    displayInternships(filtered);
}
searchInput.addEventListener("input", filterData);
domainSelect.addEventListener("change", filterData);
displayInternships(internships);